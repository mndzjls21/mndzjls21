![Juls — Technical Project Manager and Software Developer. Animated terminal profile with skills and selected projects.](./assets/profile-terminal.svg)

Hi, I’m **Juls**, a developer and technical project manager based in the Philippines. My favorite question at the start of a project is **“Can you walk me through how you do that today?”** The answer shapes what I build, from tools for barangay health workers to inventory planners for online sellers.

[Portfolio](https://mndzjls.vercel.app/) · [LinkedIn](https://www.linkedin.com/in/mendoza-julius-ceasar-v-2a7318388) · [Email](mailto:juliusmendoza809@gmail.com)
